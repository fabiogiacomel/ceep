<?
# Brasil ***************************************

//params of the your dataBase server
// parametros do seu servidor
require("db_config.inc");

// classe (class)
require("mid_excel.class");

//Estanciar
$mid_excel = new MID_SQLPARAExel;

// data to the file(Dados para o arquivo)
$sql = "select * from alunos";

//ex.:
//$mid_excel->mid_sqlparaexcel("DataBaseName", "TABLEname", RECORDSET, "FILEname");
$mid_excel->mid_sqlparaexcel("ESCOLA", "alunos", $sql, "seusDadosNoExcel");

?>